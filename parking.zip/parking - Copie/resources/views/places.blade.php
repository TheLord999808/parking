@extends("layout.layout")
@section("contenu")
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Listes des places</h6>
    <div class="d-flex justify-content-end">
        <a href="#" class="btn btn-info">ajouter une place</a>
    </div>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">First</th>
          <th scope="col">Last</th>
          <th scope="col">Handle</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td>Mark</td>
          <td>Otto</td>
          <td>@mdo</td>
          <td>
            <a href="#" class="btn btn-info">modifier</a>
            <a href="#" class="btn btn-danger">supprimer</a>
          </td>
        </tr>
        <tr>
          <th scope="row">2</th>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>@fat</td>
          <td>
            <a href="#" class="btn btn-info">modifier</a>
            <a href="#" class="btn btn-danger">supprimer</a>
          </td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td colspan="2">Larry the Bird</td>
          <td>@twitter</td>
          <td>
            <a href="#" class="btn btn-info">modifier</a>
            <a href="#" class="btn btn-danger">supprimer</a>
          </td>
        </tr>
      </tbody>
    </table>

    <small class="d-block text-end mt-3">
      <a href="#">All updates</a>
    </small>
  </div>
@endsection